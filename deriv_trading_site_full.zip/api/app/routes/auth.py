from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ..db import async_session
from ..models import User
from passlib.context import CryptContext
import jwt, os, datetime

router = APIRouter()
pwd_ctx = CryptContext(schemes=['bcrypt'], deprecated='auto')
JWT_SECRET = os.getenv('JWT_SECRET', 'replace_me_supersecret')

class RegisterIn(BaseModel):
    email: str
    password: str

@router.post('/register')
async def register(inp: RegisterIn):
    async with async_session() as session:
        q = await session.execute(User.__table__.select().where(User.email==inp.email))
        if q.first():
            raise HTTPException(400, 'User exists')
        hashed = pwd_ctx.hash(inp.password)
        user = User(email=inp.email, password_hash=hashed)
        session.add(user)
        await session.commit()
        return {'ok': True}

class LoginIn(BaseModel):
    email: str
    password: str

@router.post('/login')
async def login(inp: LoginIn):
    async with async_session() as session:
        q = await session.execute(User.__table__.select().where(User.email==inp.email))
        row = q.first()
        if not row:
            raise HTTPException(401, 'Invalid credentials')
        user = row[0]
        if not pwd_ctx.verify(inp.password, user.password_hash):
            raise HTTPException(401, 'Invalid credentials')
        token = jwt.encode({'sub': user.id, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=8)}, JWT_SECRET, algorithm='HS256')
        return {'access_token': token}
