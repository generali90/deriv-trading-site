import os
from fastapi import FastAPI
from .routes import auth, markets, trades, health
from .db import init_db
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title='Deriv Platform (Demo)')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event('startup')
async def startup_event():
    await init_db()

app.include_router(health.router, prefix='')
app.include_router(auth.router, prefix='/auth')
app.include_router(markets.router, prefix='/markets')
app.include_router(trades.router, prefix='/trades')
